package com.zybooks.turco_michael_weight_tracking;

public class CustomNotifications{
    // TODO: make class to handle sending notifications

    // all the work is done up to the point of sending the notification,
    // just need a single function to create a notification with text input
}